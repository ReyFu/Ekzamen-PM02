﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp666
{
    public partial class Form2 : Form
    {
        EGGzamenEntities1 bd=new EGGzamenEntities1();
        public Form2()
        {
            InitializeComponent();
            this.rieltorsTableAdapter.Fill(this.eGGzamenDataSet.Rieltors);

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            frm.FormClosed += Form1_FormClosed;
            frm.Set(Convert.ToInt32(dataGridView1.Rows[dataGridView1.SelectedCells[0].RowIndex].Cells[4].Value.ToString()));
            frm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.FormClosed += Form1_FormClosed;
            frm.Show();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.rieltorsTableAdapter.Fill(this.eGGzamenDataSet.Rieltors);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult res= MessageBox.Show("Вы уверены, что хотите удалить запись?", "Удаление", MessageBoxButtons.YesNo);
            if (res == DialogResult.Yes)
            {
                int id = Convert.ToInt32(dataGridView1.Rows[dataGridView1.SelectedCells[0].RowIndex].Cells[4].Value.ToString());
                var rie = (from Rieltors in bd.Rieltors where (Rieltors.id == id) select Rieltors).First();
                bd.Rieltors.Remove(rie);
                bd.SaveChanges();
                this.rieltorsTableAdapter.Fill(this.eGGzamenDataSet.Rieltors);
            }
        }
    }
}
