﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp666
{
    public partial class Form3 : Form
    {
        EGGzamenEntities1 bd = new EGGzamenEntities1();
        public int idd;
        Rieltors r;
        public Form3()
        {
            InitializeComponent();
        }

        public void Set(int id)
        {
            idd = id;
            r = (from Rieltors in bd.Rieltors where Rieltors.id == idd select Rieltors).ToArray()[0];
            textBox1.Text = r.Фамилия;
            textBox2.Text = r.Имя;
            textBox3.Text = r.Отчество;
            maskedTextBox1.Text = r.Доля_от_комиссии.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try { if (Convert.ToInt32(maskedTextBox1.Text) > 100) { MessageBox.Show("Доля не может быть больше 100"); goto bruh; } else { r.Доля_от_комиссии = Convert.ToInt32(maskedTextBox1.Text); } } catch { MessageBox.Show("не корректное значение в поле доля"); goto bruh; }
            if (textBox1.Text.Length > 50) { MessageBox.Show("Фамилия слишком длинная"); goto bruh; } else { r.Фамилия = textBox1.Text; }
            if (textBox2.Text.Length > 50) { MessageBox.Show("Имя слишком длинное"); goto bruh; } else { r.Имя = textBox2.Text; }
            if (textBox3.Text.Length > 50) { MessageBox.Show("Отчетсво слишком длинное"); goto bruh; } else { r.Отчество = textBox3.Text; }

            bd.SaveChanges();
            Close();
        bruh:;
        }
    }
}
