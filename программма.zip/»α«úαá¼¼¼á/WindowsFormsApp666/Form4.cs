﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp666
{
    public partial class Form4 : Form
    {
        EGGzamenEntities1 bd = new EGGzamenEntities1();
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

            private void button1_Click(object sender, EventArgs e)
            {
            Rieltors r = new Rieltors();

            try { if (Convert.ToInt32(maskedTextBox1.Text) > 100) { MessageBox.Show("Доля не может быть больше 100"); goto bruh; } else { r.Доля_от_комиссии = Convert.ToInt32(maskedTextBox1.Text); } } catch { MessageBox.Show("не корректное значение в поле доля");goto bruh; }
            if (textBox1.Text.Length > 50) { MessageBox.Show("Фамилия слишком длинная"); goto bruh; } else { r.Фамилия = textBox1.Text; }
            if (textBox2.Text.Length > 50) { MessageBox.Show("Имя слишком длинное"); goto bruh; } else { r.Имя = textBox2.Text; }
            if (textBox3.Text.Length > 50) { MessageBox.Show("Отчетсво слишком длинное"); goto bruh; } else { r.Отчество = textBox3.Text; }

            bd.Rieltors.Add(r);
            bd.SaveChanges();
            Close();
        bruh:;
        }
    }
}
